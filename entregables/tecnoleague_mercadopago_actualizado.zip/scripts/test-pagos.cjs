// Pruebas con PostgreSQL real y proveedor simulado. Nunca envía pagos a Mercado Pago.
require('reflect-metadata');
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { randomUUID, createHmac } = require('node:crypto');
const { execFileSync } = require('node:child_process');
const path = require('node:path');
const { PrismaClient } = require('@prisma/client');
const { PrismaService } = require('../back/dist/prisma.service');
const { PagosService } = require('../back/dist/pagos.service');
const { PagosController } = require('../back/dist/pagos.controller');
try { process.loadEnvFile(path.join(__dirname, '../back/.env')); } catch { /* DATABASE_URL puede estar inyectada. */ }
const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error('Define DATABASE_URL de un PostgreSQL local de pruebas.');
const admin = new PrismaClient({ datasourceUrl: databaseUrl });
const dbName = `tl_test_mp_${randomUUID().replaceAll('-', '')}`;
const testUrl = new URL(databaseUrl);
testUrl.pathname = `/${dbName}`;
let db, service, controller, user, other, category, app, serverUrl;
const orders = new Map();
const keys = new Map();
const creates = new Map();
const links = new Map();
const originalFetch = global.fetch;
let outage = false, timeoutCreate = false, approveOnCancel = false;
const testSecret = randomUUID();
const body = value => new Response(JSON.stringify(value), {status: 200, headers: {'Content-Type': 'application/json'}});

before(async () => {
  await admin.$executeRawUnsafe(`CREATE DATABASE "${dbName}"`);
  execFileSync(process.execPath, [require.resolve('prisma/build/index.js'), 'migrate', 'deploy', '--schema', 'back/prisma/schema.prisma'], {
    cwd: path.join(__dirname, '..'), env: {...process.env, DATABASE_URL: testUrl.href}, stdio: 'pipe',
  });
  db = new PrismaService({ datasourceUrl: testUrl.href });
  await db.$connect();
  process.env.MP_ACCESS_TOKEN = 'TEST-local-simulator-no-network';
  process.env.MP_COLLECTOR_ID = '123456';
  process.env.MP_RETURN_BASE_URL = 'https://tienda.example';
  process.env.MP_WEBHOOK_URL = 'https://backend.example/pagos/webhook';
  process.env.MP_WEBHOOK_SECRET = testSecret;
  process.env.DATABASE_URL = testUrl.href;
  process.env.JWT_SECRET = randomUUID() + randomUUID();
  process.env.MP_RECONCILIATION_DISABLED = '1';
  service = new PagosService(db);
  controller = new PagosController(service);
  user = await db.usuario.create({data: {nombre: 'Pruebas MP', email: 'mp@example.test'}});
  other = await db.usuario.create({data: {nombre: 'Otra cuenta', email: 'otra@example.test'}});
  category = await db.categoria.create({data: {nombre: 'Pruebas'}});
  global.fetch = async (url, init = {}) => {
    assert.ok(String(url).startsWith('https://api.mercadopago.com/'), 'Nunca acceder a otros destinos');
    if (outage) throw new Error('Simulated network outage');
    const route = new URL(url).pathname;
    if (route === '/v1/orders' && init.method === 'POST') {
      const key = init.headers['X-Idempotency-Key'];
      const payload = JSON.parse(init.body);
      if (keys.has(key)) assert.deepEqual(payload, keys.get(key), 'Mismo payload en reintentos');
      else {
        keys.set(key, payload);
        creates.set(key, 1);
        const id = `ORD${key.replaceAll('-', '')}`;
        orders.set(id, { id, status: 'created', status_detail: 'waiting_payment', user_id: '123456',
          currency: 'MXN', total_amount: payload.total_amount, total_paid_amount: '0.00',
          external_reference: payload.external_reference, checkout_url: `https://www.mercadopago.com.mx/checkout/${id}` });
      }
      if (timeoutCreate) { timeoutCreate = false; throw new Error('Timeout después de crear orden remota'); }
      return body(orders.get(`ORD${key.replaceAll('-', '')}`));
    }
    const id = route.split('/')[3];
    if (route.endsWith('/cancel')) {
      const order = orders.get(id);
      if (approveOnCancel) { approveOnCancel = false; Object.assign(order, {status: 'processed', status_detail: 'accredited', total_paid_amount: order.total_amount}); }
      else Object.assign(order, {status: 'cancelled', status_detail: 'cancelled'});
      return body(order);
    }
    if (route.startsWith('/v1/orders/')) {
      assert.ok(orders.has(id), `Orden simulada existente: ${id}`);
      return body(orders.get(id));
    }
    if (links.has(route)) return body(links.get(route));
    throw new Error(`Petición externa inesperada: ${route}`);
  };
  const { NestFactory } = require('@nestjs/core');
  const { AppModule } = require('../back/dist/app.module');
  app = await NestFactory.create(AppModule, {logger: false});
  await app.listen(0, '127.0.0.1');
  serverUrl = await app.getUrl();
});
after(async () => {
  global.fetch = originalFetch;
  service?.onModuleDestroy();
  if (app) await app.close();
  if (db) await db.$disconnect();
  // Solo elimina la base efímera generada por esta ejecución.
  if (/^tl_test_mp_[a-f0-9]{32}$/.test(dbName)) await admin.$executeRawUnsafe(`DROP DATABASE IF EXISTS "${dbName}" WITH (FORCE)`);
  await admin.$disconnect();
});
async function datos(stock = 5) {
  const producto = await db.producto.create({data: {nombre: 'Producto MP', descripcion: 'Prueba', precio: '19.90', imagen: '/images/logo.png', stock,
    marca: 'TEST', especificaciones: '', categoriaId: category.id}});
  return {producto, input: {nombre: 'Comprador de prueba', email: user.email, direccion: 'Domicilio ficticio 123',
    claveSolicitud: randomUUID(), renglones: [{productoId: producto.id, cantidad: 2}]}};
}
async function iniciar(stock = 5) {
  const fixture = await datos(stock);
  const result = await service.iniciarPago(fixture.input, user.id);
  const intento = await db.intentoCompra.findUniqueOrThrow({where: {id: result.intentoId}, include: {pago: true}});
  return {...fixture, result, intento, order: orders.get(intento.pago.idOrdenExterna)};
}
function acreditar(order) { Object.assign(order, {status: 'processed', status_detail: 'accredited', total_paid_amount: order.total_amount}); }
async function webhook(type, id, secret = testSecret, bodyId = id) {
  const requestId = randomUUID();
  const ts = String(Math.floor(Date.now()/1000));
  const hash = createHmac('sha256', secret).update(`id:${id.toLowerCase()};request-id:${requestId};ts:${ts};`).digest('hex');
  return controller.webhook(`ts=${ts},v1=${hash}`, requestId, id, {type, data: {id: bodyId}});
}
async function cerrar(f) {
  Object.assign(f.order, {status: 'cancelled'});
  await service.procesarWebhook('order', f.order.id);
}

test('reserva sin pedido, mismo intento no duplica y webhook acreditado crea un solo pedido', async () => {
  const f = await iniciar();
  assert.equal(await db.pedido.count(), 0);
  assert.equal((await db.producto.findUnique({where: {id: f.producto.id}})).stock, 3);
  const repeat = await service.iniciarPago(f.input, user.id);
  assert.equal(repeat.intentoId, f.result.intentoId);
  assert.equal(creates.get(f.input.claveSolicitud), 1);
  acreditar(f.order);
  const replies = await Promise.all([webhook('order', f.order.id), webhook('order', f.order.id)]);
  assert.ok(replies.every(r => r.recibido));
  const state = await service.consultarIntento(f.result.intentoId, user.id);
  assert.equal(state.estado, 'CONFIRMADO');
  assert.equal(await db.pedido.count(), 1);
  const pedido = await db.pedido.findUnique({where: {id: state.pedidoId}, include: {detalles: true, pagos: true}});
  assert.equal(pedido.status, 'PAGADO');
  assert.equal(pedido.total.toFixed(2), '39.80');
  assert.equal(pedido.pagos[0].estado, 'APROBADO');
  assert.equal(pedido.detalles[0].cantidad, 2);
  assert.equal((await db.producto.findUnique({where: {id: f.producto.id}})).stock, 3, 'No descontar otra vez al confirmar');
  await assert.rejects(() => service.consultarIntento(f.result.intentoId, other.id), /no encontrado/);
});
test('200 pendiente registra estado sin crear pedido; rechazo libera exactamente una vez', async () => {
  const f = await iniciar();
  const before = await db.pedido.count();
  const pending = await webhook('order', f.order.id);
  assert.equal(pending.resultado, 'EN_PROCESO');
  assert.equal(await db.pedido.count(), before);
  Object.assign(f.order, {status: 'failed', status_detail: 'rejected'});
  assert.equal((await webhook('order', f.order.id)).resultado, 'RECHAZADO');
  await webhook('order', f.order.id);
  assert.equal((await db.producto.findUnique({where: {id: f.producto.id}})).stock, 5);
  assert.equal(await db.pedido.count(), before);
});
test('payment y merchant_order consultan la orden canónica, nunca aprueban por sí mismos', async () => {
  const f = await iniciar();
  links.set('/v1/payments/111', {id: 111, status: 'approved', external_reference: f.order.external_reference});
  links.set('/merchant_orders/222', {id: 222, status: 'closed', external_reference: f.order.external_reference});
  assert.equal((await webhook('payment', '111', testSecret, 111)).resultado, 'EN_PROCESO');
  assert.equal((await webhook('merchant_order', '222')).resultado, 'EN_PROCESO');
  acreditar(f.order);
  assert.equal((await webhook('payment', '111')).resultado, 'CONFIRMADO');
  assert.equal((await webhook('merchant_order', '222')).resultado, 'YA_CONFIRMADO');
});
test('firma inválida y body con otro ID se rechazan; tipo ajeno se ignora explícitamente', async () => {
  await assert.rejects(() => webhook('order', '123', 'incorrecta'), /Firma inválida/);
  await assert.rejects(() => webhook('order', '123', testSecret, '456'), /no es válido/);
  assert.equal((await webhook('otro_evento', '123')).resultado, 'IGNORADO_TIPO');
  links.set('/v1/payments/333', {id: 333, external_reference: 'otra-tienda'});
  assert.equal((await webhook('payment', '333')).resultado, 'IGNORADO_AJENO');
});
test('timeout tras crear orden remota conserva reserva y recupera con la misma clave', async () => {
  const f = await datos();
  timeoutCreate = true;
  await assert.rejects(() => service.iniciarPago(f.input, user.id), /No hubo respuesta/);
  const result = await service.iniciarPago(f.input, user.id);
  assert.equal(creates.get(f.input.claveSolicitud), 1);
  assert.equal((await db.producto.findUnique({where: {id: f.producto.id}})).stock, 3);
  const order = orders.get(`ORD${f.input.claveSolicitud.replaceAll('-', '')}`);
  assert.equal(result.intentoId, f.input.claveSolicitud);
  await cerrar({order});
});
test('importe, vendedor, moneda y referencia incorrectos impiden confirmar', async () => {
  const f = await iniciar();
  acreditar(f.order);
  for (const [field, value] of [['total_paid_amount','0.01'], ['user_id','999'], ['currency','USD'], ['external_reference','otra']]) {
    const original = f.order[field];
    f.order[field] = value;
    await assert.rejects(() => webhook('order', f.order.id), /no coincide|no coincide con/);
    assert.equal((await db.intentoCompra.findUnique({where: {id: f.result.intentoId}})).pedidoId, null);
    f.order[field] = original;
  }
  await cerrar(f);
});
test('expiración con fallo de red NO libera; conciliador cancela y libera al recuperar conexión', async () => {
  const f = await iniciar();
  await db.intentoCompra.update({where: {id: f.result.intentoId}, data: {expiraEn: new Date(Date.now()-1000)}});
  outage = true;
  const result = await service.consultarIntento(f.result.intentoId, user.id);
  assert.ok(result.aviso);
  assert.equal((await db.producto.findUnique({where: {id: f.producto.id}})).stock, 3);
  outage = false;
  await db.intentoCompra.update({where: {id: f.result.intentoId}, data: {proximaRevision: new Date(0)}});
  await service.revisarPendientes();
  const actual = await db.intentoCompra.findUnique({where: {id: f.result.intentoId}});
  assert.equal(actual.estado, 'EXPIRADO');
  assert.equal((await db.producto.findUnique({where: {id: f.producto.id}})).stock, 5);
});
test('aprobación concurrente con cancelación se confirma sin liberar stock', async () => {
  const f = await iniciar();
  await db.intentoCompra.update({where: {id: f.result.intentoId}, data: {expiraEn: new Date(0)}});
  approveOnCancel = true;
  const result = await service.consultarIntento(f.result.intentoId, user.id);
  assert.equal(result.estado, 'CONFIRMADO');
  assert.equal((await db.producto.findUnique({where: {id: f.producto.id}})).stock, 3);
});
test('una cuenta no abre dos intentos y la misma clave no admite otros datos', async () => {
  const f = await iniciar();
  await assert.rejects(() => service.iniciarPago({...f.input, nombre: 'Otra persona'}, user.id), /otros datos/);
  await assert.rejects(() => service.iniciarPago({...f.input, claveSolicitud: randomUUID()}, user.id), /pago en proceso/);
  await cerrar(f);
});
test('dos compradores no pueden reservar la última existencia simultáneamente', async () => {
  const f = await datos(2);
  const results = await Promise.allSettled([
    service.iniciarPago(f.input, user.id),
    service.iniciarPago({...f.input, claveSolicitud: randomUUID()}, other.id),
  ]);
  assert.equal(results.filter(r => r.status === 'fulfilled').length, 1);
  assert.equal((await db.producto.findUnique({where: {id: f.producto.id}})).stock, 0);
  const ok = results.find(r => r.status === 'fulfilled').value;
  await cerrar({order: orders.get(`ORD${ok.intentoId.replaceAll('-', '')}`)});
});
test('pago tardío tras rechazo readquiere stock y crea solo un pedido', async () => {
  const f = await iniciar();
  Object.assign(f.order, {status: 'failed'});
  await webhook('order', f.order.id);
  acreditar(f.order);
  assert.equal((await webhook('order', f.order.id)).resultado, 'CONFIRMADO');
  assert.equal((await db.producto.findUnique({where: {id: f.producto.id}})).stock, 3);
});
test('pago tardío sin stock devuelve error reintentable y deja incidencia visible', async () => {
  const f = await iniciar();
  Object.assign(f.order, {status: 'failed'});
  await webhook('order', f.order.id);
  await db.producto.update({where: {id: f.producto.id}, data: {stock: 0}});
  acreditar(f.order);
  await assert.rejects(() => webhook('order', f.order.id), /sin stock/);
  const actual = await db.intentoCompra.findUnique({where: {id: f.result.intentoId}});
  assert.equal(actual.pedidoId, null);
  assert.ok(actual.ultimoError);
  assert.equal(actual.estado, "EN_PROCESO");
  await db.producto.update({where: {id: f.producto.id}, data: {stock: 2}});
  await webhook("order", f.order.id);
});
test('cancelación explícita libera reserva; solo el dueño puede solicitarla', async () => {
  const f = await iniciar();
  await assert.rejects(() => service.cancelarIntento(f.result.intentoId, other.id), /no encontrado/);
  const state = await service.cancelarIntento(f.result.intentoId, user.id);
  assert.equal(state.estado, 'CANCELADO');
  assert.equal(state.pedidoId, null);
  assert.equal(state.checkoutUrl, null);
  assert.equal((await db.producto.findUnique({where: {id: f.producto.id}})).stock, 5);
});
test('evento reembolsado conserva el pedido y no repone stock automáticamente', async () => {
  const f = await iniciar();
  acreditar(f.order);
  await webhook('order', f.order.id);
  Object.assign(f.order, {status: 'refunded', status_detail: 'refunded', total_paid_amount: '0.00'});
  await webhook('order', f.order.id);
  const state = await service.consultarIntento(f.result.intentoId, user.id);
  assert.equal(state.estado, 'CONFIRMADO');
  assert.equal((await db.pago.findUnique({where: {intentoId: state.intentoId}})).estado, 'REEMBOLSADO');
  assert.equal((await db.producto.findUnique({where: {id: f.producto.id}})).stock, 3);
});

test('HTTP GraphQL + webhook: autenticación, estado pendiente, 401, confirmación y errores 503', async () => {
  const { JwtService } = require('@nestjs/jwt');
  const token = new JwtService({secret: process.env.JWT_SECRET}).sign({sub: user.id}, {expiresIn: '1h'});
  const gql = async (query, variables = {}, auth = true) => {
    const response = await originalFetch(`${serverUrl}/graphql`, {method: 'POST',
      headers: {'Content-Type': 'application/json', ...(auth ? {Authorization: `Bearer ${token}`} : {})},
      body: JSON.stringify({query, variables})});
    return response.json();
  };
  const f = await datos();
  const query = 'mutation($datos:PedidoInput!){iniciarPago(datos:$datos){intentoId estado checkoutUrl pedidoId}}';
  assert.equal((await gql(query, {datos: f.input}, false)).errors[0].extensions.code, 'UNAUTHENTICATED');
  const start = await gql(query, {datos: f.input});
  assert.ok(!start.errors, JSON.stringify(start.errors));
  const id = start.data.iniciarPago.intentoId;
  assert.equal(start.data.iniciarPago.pedidoId, null);
  assert.equal((await gql('{intentoActivo}')).data.intentoActivo, id);
  await db.usuario.update({where: {id: user.id}, data: {rol: 'ADMIN'}});
  const adminPayments = await gql('{adminPagos{items{intentoId estadoIntento ultimoError pedido{id}}}}');
  assert.ok(!adminPayments.errors, JSON.stringify(adminPayments.errors));
  assert.equal(adminPayments.data.adminPagos.items.find(p => p.intentoId === id).pedido, null);
  const order = orders.get(`ORD${id.replaceAll('-', '')}`);
  const requestId = randomUUID(), ts = String(Math.floor(Date.now()/1000));
  const signature = createHmac('sha256', testSecret).update(`id:${order.id.toLowerCase()};request-id:${requestId};ts:${ts};`).digest('hex');
  const notify = headers => originalFetch(`${serverUrl}/pagos/webhook?data.id=${order.id}`, {method: 'POST',
    headers: {'Content-Type': 'application/json', ...headers}, body: JSON.stringify({type: 'order', data: {id: order.id}})});
  assert.equal((await notify({})).status, 401);
  const headers = {'x-signature': `ts=${ts},v1=${signature}`, 'x-request-id': requestId};
  const pending = await notify(headers);
  assert.equal(pending.status, 200);
  assert.equal((await pending.json()).resultado, 'EN_PROCESO');
  outage = true;
  assert.equal((await notify(headers)).status, 503);
  outage = false;
  acreditar(order);
  assert.equal((await notify(headers)).status, 200);
  const state = await gql('query($id:ID!){estadoIntento(intentoId:$id){estado pedidoId checkoutUrl renglones{productoId cantidad}}}', {id});
  assert.equal(state.data.estadoIntento.estado, 'CONFIRMADO');
  assert.ok(state.data.estadoIntento.pedidoId);
  assert.equal(state.data.estadoIntento.checkoutUrl, null);
});
