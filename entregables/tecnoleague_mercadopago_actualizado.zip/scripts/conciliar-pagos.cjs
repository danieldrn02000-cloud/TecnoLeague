// Alternativa para un cron de backend cuando no se mantiene un proceso Nest activo.
require('reflect-metadata');
const path = require('node:path');
try { process.loadEnvFile(path.join(__dirname, '../back/.env')); } catch { /* Configuración inyectada en el proceso. */ }
const { PrismaService } = require('../back/dist/prisma.service');
const { PagosService } = require('../back/dist/pagos.service');
const db = new PrismaService();
(async () => {
  if (!process.env.MP_ACCESS_TOKEN || !process.env.MP_COLLECTOR_ID) throw new Error('Faltan MP_ACCESS_TOKEN o MP_COLLECTOR_ID.');
  await db.$connect();
  const service = new PagosService(db);
  await service.revisarPendientes();
  const incidencias = await db.intentoCompra.count({where: {ultimoError: {not: null}, estado: {in: ['INICIADO', 'EN_PROCESO']}}});
  console.log(`Conciliación ejecutada (hasta 20 intentos). Incidencias pendientes: ${incidencias}.`);
  if (incidencias) process.exitCode = 1;
})().catch(error => {
  console.error(error instanceof Error ? error.message : 'Error de conciliación.');
  process.exitCode = 1;
}).finally(() => db.$disconnect());
