const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');
const source = fs.readFileSync(path.join(__dirname, '../front/src/lib/checkout.ts'), 'utf8');
const js = ts.transpileModule(source, {compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022}}).outputText;
const exportsModule = {};
const values = new Map();
const storage = {getItem: key => values.get(key) ?? null, setItem: (key,value) => values.set(key,value), removeItem: key => values.delete(key)};
vm.runInNewContext(js, {exports: exportsModule, localStorage: storage, navigator: {}, window: {dispatchEvent() {}}, Event: class Event {}});
const lineas = [{producto: {id: 1}, cantidad: 5}, {producto: {id: 2}, cantidad: 1}];
const compra = {intentoId: 'test-compra', pedidoId: 123, estado: 'CONFIRMADO', renglones: [{productoId: 1, cantidad: 2}]};

test('descuenta solo las unidades compradas y conserva otros productos y adiciones posteriores', () => {
  assert.equal(JSON.stringify(exportsModule.descontarCompra(lineas, compra.renglones)), JSON.stringify([
    {producto: {id: 1}, cantidad: 3}, {producto: {id: 2}, cantidad: 1},
  ]));
});
test('confirmación limpia una vez; recargar retorno no vuelve a descontar', async () => {
  storage.setItem('tl-carrito-v1', JSON.stringify(lineas));
  exportsModule.guardarIntento(1, compra.intentoId);
  await exportsModule.aplicarCompraConfirmada(1, compra);
  await exportsModule.aplicarCompraConfirmada(1, compra);
  assert.equal(JSON.parse(storage.getItem('tl-carrito-v1'))[0].cantidad, 3);
  assert.equal(exportsModule.leerIntento(1), null);
});
test('rechazado o pendiente no borra carrito y los metadatos se separan por usuario', async () => {
  const antes = storage.getItem('tl-carrito-v1');
  exportsModule.guardarIntento(2, 'otra-compra');
  await exportsModule.aplicarCompraConfirmada(2, {...compra, estado: 'RECHAZADO'});
  await exportsModule.aplicarCompraConfirmada(2, {...compra, estado: 'EN_PROCESO'});
  assert.equal(storage.getItem('tl-carrito-v1'), antes);
  assert.equal(exportsModule.leerIntento(2), 'otra-compra');
  assert.equal(exportsModule.leerIntento(1), null);
});
