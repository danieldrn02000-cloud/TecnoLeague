# Despliegue: Netlify + Render + PostgreSQL + Mercado Pago

## Arquitectura

- Netlify: frontend Astro SSR, cookies de sesión y puente `/api/graphql`.
- Render Web Service: backend NestJS, endpoint `/graphql`, receptor `/pagos/webhook` y conciliador de pagos.
- PostgreSQL: tablas, intentos de compra, reservas, pagos y pedidos.
- Mercado Pago llama la URL pública de Render. La URL de retorno del comprador apunta a Netlify.

La migración SQL no necesita ejecutarse en Netlify. Se ejecuta desde Render contra PostgreSQL. Netlify no necesita `DATABASE_URL` ni secretos de Mercado Pago. El backend puede permanecer público en Render aunque desarrolles el frontend localmente; para pruebas totalmente locales también es posible un túnel HTTPS, pero no es necesario para este despliegue.

## Corregir EstadoIntento / IntentoCompraGetPayload / Prisma.Decimal ausentes

Estos errores indican que `@prisma/client` no contiene los tipos generados a partir del esquema actualizado. Pueden deberse a generación no ejecutada/fallida, esquema incompleto o cliente generado desde otro esquema. No se resuelven con `any` ni cambiando imports.

Detén `npm run dev`. Abre la terminal en la raíz que contiene el package.json general, package-lock.json, back/ y front/. En Windows los siguientes comandos también funcionan:

```powershell
npm ci
npx prisma validate --schema back/prisma/schema.prisma
npm run db:generate
npm run build -w back
npm run dev
```

Ejecuta cada comando después de que el anterior termine correctamente. Si la generación falla, corrige su error antes de continuar. `npm ci` reinstala usando el lockfile y elimina el cliente viejo contenido en node_modules. No borra `.env` ni la base de datos. No borres el lockfile ni actualices Prisma a una versión distinta como solución.

El esquema copiado debe incluir `enum EstadoIntento`, `model IntentoCompra` y `model DetalleIntento`, las relaciones y las modificaciones de `Pago`, además de la carpeta completa de la migración `202610150001_checkout_intentos`. Copiar solo pagos.service.ts no basta.

`prisma generate` genera código y tipos; **no crea tablas** ni necesita recibir un webhook. `prisma migrate deploy` aplica SQL a la base configurada; **no genera el cliente**. Por eso se necesitan ambos pasos. La generación requiere una DATABASE_URL con formato válido y acceso a los motores de Prisma cuando no estén en caché, pero no necesita un pago ni una llamada entrante de Mercado Pago.

La actualización de back/package.json agrega `predev` y `prebuild`: npm genera Prisma antes del desarrollo y de compilar el backend; si esa generación falla, no continúa. El package.json raíz agrega `build:render` y `start:render`. No cambiaron versiones de dependencias ni el lockfile.

## Render: ajustes del Web Service

Usa la raíz del repositorio como Root Directory (vacía o `.`). Así npm encuentra el lockfile compartido y ambos workspaces. No pongas `back` como raíz con estos comandos.

Build Command:

```bash
npm ci --include=dev && npm run build:render
```

Start Command:

```bash
npm run start:render
```

El build genera el cliente de Prisma antes de compilar NestJS. El arranque ejecuta las migraciones y, si terminan bien, inicia el backend compilado. Una migración fallida impide arrancar contra un esquema incompatible. En reinicios posteriores, migrate deploy solo aplica lo que siga pendiente.

Si tu servicio dispone de Pre-Deploy Command, puedes usar `npm run db:migrate` ahí y `npm run start -w back` como Start Command. Elige una de las dos estrategias. Pre-deploy evita mezclar ese trabajo con el arranque y debe ocurrir antes de servir la versión nueva. Respalda la base antes del primer despliegue de la migración. No uses migrate reset ni db push en este flujo.

Mantén Prisma CLI, TypeScript y herramientas de build disponibles: el comando usa --include=dev porque estas dependencias están en devDependencies. start:render también necesita Prisma CLI para ejecutar migraciones. No hagas prune --omit=dev antes de ese arranque sin cambiar la estrategia de migración.

### Variables de Render

| Variable | Valor a configurar | Por qué |
| --- | --- | --- |
| NODE_VERSION | 24 | Mantiene un runtime compatible y consistente. |
| NODE_ENV | production | Selecciona el modo de ejecución de producción. |
| DATABASE_URL | Conexión PostgreSQL de la base que se va a migrar | La usan Prisma y las migraciones. Si PostgreSQL está en Render y es accesible desde el servicio, usa su conexión interna. Mantén el TLS requerido por el proveedor. |
| JWT_SECRET | Secreto aleatorio privado, estable, de al menos 32 bytes | Firma y valida los JWT de sesión. Cambiarlo invalida las sesiones existentes. |
| AUTH_BRIDGE_SECRET | Secreto aleatorio privado idéntico al de Netlify | Autoriza el login/registro que Astro envía a NestJS. Es distinto de JWT_SECRET y del secreto de MP. |
| FRONTEND_ORIGIN | https://TU-SITIO.netlify.app | Configura el origen permitido por CORS. Solo origen: sin ruta ni slash final. |
| MP_ACCESS_TOKEN | Credencial del vendedor para la aplicación/producto de pruebas | Permite crear y consultar órdenes en Mercado Pago. No es la public key ni la credencial del comprador. |
| MP_COLLECTOR_ID | ID numérico del vendedor propietario del token | Permite comprobar que la orden pertenece al vendedor esperado. |
| MP_WEBHOOK_SECRET | Secreto de firma de Webhooks de la aplicación/configuración correcta | Verifica x-signature y evita aceptar notificaciones falsificadas. No es MP_ACCESS_TOKEN. |
| MP_WEBHOOK_URL | https://TU-BACKEND.onrender.com/pagos/webhook | Destino público de las notificaciones del proveedor. Incluye esta ruta. |
| MP_RETURN_BASE_URL | https://TU-SITIO.netlify.app | Raíz del frontend para construir /pago/retorno?intento=...; no incluyas esa ruta en la variable. |
| MP_RECONCILIATION_DISABLED | 0 con Nest persistente; 1 si usas cron externo | Controla el conciliador de reservas/pagos que se ejecuta cada minuto. |

Render suministra PORT. El código ya lee process.env.PORT y escucha en 0.0.0.0; no necesitas fijarlo a 4000 ni configurar HOST para que Render publique el servicio.

Opcionales: ADMIN_EMAIL, ADMIN_PASSWORD y ADMIN_NAME solo para preparar un administrador mediante db:seed; no cambian usuarios existentes. PUBLIC_SITE_URL, RESEND_API_KEY y PASSWORD_RESET_FROM pertenecen a recuperación de contraseña, no al cobro. Si activas esa función, PUBLIC_SITE_URL debe ser la raíz pública de Netlify y el remitente debe estar autorizado en Resend. MP_TEST_BUYER_EMAIL es solo una referencia de configuración en el ejemplo; el flujo actual no la lee para elegir el comprador.

Los secretos se ingresan en las variables privadas del proveedor; no se copian al repositorio ni al ZIP.

## Netlify: ajustes y variables

Este paquete incluye netlify.toml. Establece Base directory en la raíz del repositorio y Package directory en front (en los ajustes de monorepo si corresponde). Comando y salida:

```text
Build command: npm run build -w front
Publish directory: front/dist
```

Netlify instala las dependencias desde el lockfile de la raíz. El adaptador @astrojs/netlify ya está configurado en front/astro.config.mjs. No uses el build completo del backend ni ejecutes migraciones PostgreSQL como parte de cada deploy preview de Netlify.

| Variable | Valor | Por qué |
| --- | --- | --- |
| BACKEND_GRAPHQL_URL | https://TU-BACKEND.onrender.com/graphql | Astro SSR envía las consultas a Render. localhost en Netlify apuntaría a la propia función, no a tu PC ni a Render. |
| AUTH_BRIDGE_SECRET | Exactamente el mismo valor privado de Render | Astro agrega el encabezado de autenticación del puente al registrar o iniciar sesión. |
| NODE_VERSION | 24, ya declarado en netlify.toml | Runtime de build compatible con el proyecto. |
| ASTRO_TELEMETRY_DISABLED | 1, ya declarado en netlify.toml | Desactiva telemetría; no interviene en cookies ni pagos. |

BACKEND_GRAPHQL_URL y AUTH_BRIDGE_SECRET se leen mediante import.meta.env en código del servidor Astro. Configúralas para Builds y Functions cuando Netlify permita elegir ámbitos y reconstruye el sitio tras cambiarlas. No uses prefijos PUBLIC_ o VITE_ para el secreto. No copies MP_ACCESS_TOKEN, MP_WEBHOOK_SECRET, JWT_SECRET o DATABASE_URL a Netlify: el frontend no los necesita.

## Orden de implementación

1. Aplica todos los archivos de la actualización y estos archivos de despliegue al mismo proyecto. Conserva .env privados y el lockfile original.
2. Crea/selecciona PostgreSQL y configura DATABASE_URL y los secretos del backend en Render.
3. Usa los comandos de build/arranque anteriores. Confirma que migrate deploy encuentra y aplica la quinta migración y que NestJS arranca.
4. Configura las variables de Netlify y despliega el frontend actualizado. Obtén su dominio HTTPS definitivo.
5. Completa FRONTEND_ORIGIN y MP_RETURN_BASE_URL de Render con ese dominio. Completa MP_WEBHOOK_URL con el dominio público de Render. Guarda/reinicia el backend según las opciones del proveedor.
6. En la aplicación de Mercado Pago, configura la URL pública de Render y los eventos Orders correspondientes al producto/entorno de pruebas. Asegúrate de que el secreto de firma coincide. Los eventos adicionales payment/merchant_order solo actúan como señales para verificar la orden canónica del intento, según la guía de implementación.
7. Realiza la compra de prueba completa: carrito → intento reservado → checkout MP → acreditación verificada → pedido PAGADO. Revisa entregas y logs del backend. El rechazo debe conservar el carrito sin crear pedido.

Para comprobar que el receptor está expuesto puedes hacer un POST sin firma a /pagos/webhook: debe rechazarlo, normalmente con 401 si el secreto está configurado. No es una prueba de pago. Un GET en esa ruta puede devolver 404 porque solo recibe POST. Una firma faltante no debe deshabilitarse para lograr un 200.

## Disponibilidad y conciliación

Si el servicio Render se suspende por inactividad, los temporizadores no corren mientras está dormido; el arranque en frío también puede retrasar la entrega de un webhook. Usa un proceso siempre activo o un cron de backend que ejecute `node scripts/conciliar-pagos.cjs` cada minuto con las mismas variables y acceso a la base. No interpretes el cierre del navegador como rechazo ni liberes reservas cuyo estado en MP siga siendo incierto.

La migración y los tipos se verificaron en el entorno de trabajo, no en tu máquina Windows. Los despliegues de Netlify/Render y un pago real de prueba necesitan validación en tus cuentas. Las instrucciones completas del flujo, respuestas HTTP, pruebas y límites están en README_IMPLEMENTACION_MERCADO_PAGO.md.

## Si la dirección de entrega no permite escribir

Se corrigió `front/src/screens/Checkout.tsx`: los campos solo se deshabilitan mientras se envía el pago. La consulta inicial `intentoActivo` ya no bloquea la escritura y, si falla, ofrece `Reintentar comprobación`. El botón de pagar permanece bloqueado hasta verificar que no existe un intento anterior.

Si esa comprobación falla en Netlify, verifica `BACKEND_GRAPHQL_URL` y que Render tenga desplegados el esquema GraphQL y `pagos.resolver.ts` actualizados con `intentoActivo`. La consulta requiere sesión válida. Si se detecta un intento pendiente, el enlace de resultado permite revisarlo o cancelarlo; no borres el identificador del navegador para forzar otro cobro. Editar el formulario no modifica los datos de un intento ya enviado.
