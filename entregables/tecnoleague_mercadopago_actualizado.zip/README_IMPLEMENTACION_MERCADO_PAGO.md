# Implementación: pedido después del pago de Mercado Pago

Para configurar hosting y resolver tipos Prisma ausentes, sigue [la guía Netlify + Render](README_DESPLIEGUE_NETLIFY_RENDER.md). La migración se ejecuta desde el backend de Render contra PostgreSQL; Netlify publica el frontend.

Este paquete contiene archivos completos actualizados y nuevos, con sus rutas relativas a la raíz de `tecnoleague_auth_system`. Fue preparado sobre el commit `048ef0ec7afb23180d412535586ae81d71c47426`. Incluye también la corrección anterior del cierre de sesión en Netlify. No contiene dependencias, compilaciones, archivos `.env`, credenciales ni datos de la base de desarrollo. No se hizo commit, push ni despliegue.

## 1. Qué cambia

Flujo nuevo de la tienda:

1. El cliente conserva su carrito y solicita `iniciarPago(datos: PedidoInput!)`.
2. El servidor valida productos, cantidades y precios actuales, y guarda un `IntentoCompra`. Reserva existencias durante el checkout. Todavía **no crea un Pedido**.
3. Se crea una orden de Orders (`POST /v1/orders`) y se abre el `checkout_url` devuelto por Mercado Pago.
4. El webhook, la consulta de retorno o el conciliador consultan la orden directamente a Mercado Pago.
5. Solo `status=processed` + `status_detail=accredited`, vendedor, moneda, referencia, importe y total acreditado correctos permiten crear un pedido `PAGADO`, con su pago `APROBADO`, en una transacción.
6. Rechazo, cancelación o vencimiento verificados liberan la reserva y conservan el carrito. Una caída de red conserva la reserva mientras se resuelve el resultado.
7. El navegador descuenta del carrito las unidades compradas al consultar la confirmación. Reabrir el retorno no las descuenta de nuevo en condiciones normales de almacenamiento. Los productos distintos y las unidades añadidas por encima de lo comprado se conservan.

La reserva descuenta `Producto.stock`, que representa las unidades disponibles. El movimiento `RESERVA` registra la salida; al confirmar, `PEDIDO` registra cantidad 0 porque esas unidades ya se descontaron. `LIBERACION` devuelve las unidades cuando corresponde. No son tres descuentos distintos.

Los pedidos históricos y la API anterior `crearPedido` de pago al recibir se conservan por compatibilidad; el nuevo checkout **no la llama**. Las órdenes antiguas `TL-PAGO-*` pueden seguir confirmándose con notificaciones `order` y validación del proveedor. No se convierten ni borran pedidos pendientes históricos automáticamente.

## 2. Aplicar los archivos

1. Guarda una copia de tu proyecto y un respaldo de la base que vayas a migrar.
2. Extrae el ZIP en una carpeta temporal. Copia `back/`, `front/`, `scripts/` y los README sobre las mismas rutas de tu proyecto. Si tienes cambios posteriores, compara los archivos antes de reemplazarlos: son archivos completos, no un proyecto completo ni un parche universal.
3. Conserva tus archivos `back/.env` y `front/.env`. El `.env.example` es una referencia; no reemplaces tus valores por sus marcadores.
4. Requisitos: Node.js >=22.12, npm y PostgreSQL >=12. Las pruebas se verificaron con Node 24 y PostgreSQL 17. No hay nuevas dependencias npm ni cambios de lockfile.
5. Desde la raíz del proyecto:

```bash
npm ci
npm run db:generate
npm run db:migrate
npm run build
```

`db:migrate` aplica las migraciones existentes y la nueva `202610150001_checkout_intentos`. No uses `prisma migrate reset`, `db push` ni cargues `db.sql` para aplicar esta actualización. No edites migraciones ya aplicadas. El seed no es necesario en una base existente; usa `npm run db:seed` solo si necesitas preparar el catálogo inicial.

La migración agrega las tablas `intentos_compra` y `detalle_intento`, los estados de intento, dos tipos de movimiento y la relación opcional `pagos.intento_id`. `pagos.pedido_id` pasa a ser opcional: un pago puede existir antes del pedido. Los registros existentes permanecen.

## 3. Configurar variables

En el backend NestJS configura estas variables de forma privada, además de `DATABASE_URL`, `JWT_SECRET`, `AUTH_BRIDGE_SECRET`, `PORT` y `FRONTEND_ORIGIN` que ya utiliza el proyecto:

```dotenv
MP_ACCESS_TOKEN=ACCESS_TOKEN_DEL_VENDEDOR_DE_PRUEBA
MP_COLLECTOR_ID=ID_NUMERICO_DEL_VENDEDOR
MP_RETURN_BASE_URL=https://TU-SITIO.netlify.app
MP_WEBHOOK_URL=https://TU-BACKEND/pagos/webhook
MP_WEBHOOK_SECRET=SECRETO_DE_FIRMA_DE_WEBHOOKS
MP_RECONCILIATION_DISABLED=0
```

- `MP_COLLECTOR_ID`: ID del vendedor propietario del token, no el comprador. Puedes comprobar la identidad de la credencial con `GET https://api.mercadopago.com/users/me` mediante un cliente privado. No publiques el token ni su respuesta completa. La integración exige que la orden consultada tenga ese `user_id`.
- Usa las credenciales y cuentas de prueba correspondientes al producto habilitado en tu aplicación de México. El comprador debe ser distinto del vendedor. Sigue las instrucciones y medios de prueba actuales de Mercado Pago para ese producto; no uses una tarjeta real.
- `MP_RETURN_BASE_URL`: raíz del frontend, sin `/pago/retorno` ni parámetros. El servidor agrega `?intento=UUID` a las URLs de retorno.
- `MP_WEBHOOK_URL`: URL HTTPS pública de NestJS, con `/pagos/webhook`. No es `/graphql` ni la página de retorno de Netlify. El código la envía como `config.online.callback_url`.
- `MP_WEBHOOK_SECRET`: secreto de firma de la misma aplicación y configuración de Webhooks utilizada. No es el access token.
- Los secretos MP van **solo en el backend**. No agregues prefijos `PUBLIC_` o `VITE_` ni los incluyas en React.

En el frontend SSR conserva:

```dotenv
BACKEND_GRAPHQL_URL=https://TU-BACKEND/graphql
AUTH_BRIDGE_SECRET=MISMO_VALOR_QUE_EL_BACKEND
```

Reinicia/reconstruye cada servicio después de actualizar sus variables. El backend debe permitir HTTPS saliente a `api.mercadopago.com`; Prisma necesita `binaries.prisma.sh` durante su generación si los motores no están disponibles. No desactives checksums ni TLS para resolver descargas.

## 4. Configurar Webhooks en Mercado Pago

En la aplicación que corresponde a las credenciales, configura el endpoint HTTPS público y los eventos de Orders disponibles para el producto. Comprueba el entorno de pruebas y el secreto de firma que te muestra la plataforma.

La integración continúa usando **Orders**. Aceptar otras notificaciones no la convierte en Checkout Pro por preferencias ni en Checkout API basado exclusivamente en `/v1/payments`.

| Tipo recibido | Qué hace el servidor |
| --- | --- |
| `order` | Consulta `/v1/orders/{id}` y verifica la orden vinculada. |
| `payment` | Consulta `/v1/payments/{id}`; localiza el intento por `external_reference` o por un `order.id` ya vinculado y vuelve a consultar su orden de Orders. |
| `merchant_order` | Consulta `/merchant_orders/{id}`; si su referencia identifica un intento local, verifica la orden de Orders de ese intento. |
| Otro tipo firmado | Responde `200` con `IGNORADO_TIPO`, sin modificar pedidos. |
| Recurso ajeno | Responde `200` con `IGNORADO_AJENO`, sin crear pedidos. |

Habilita `payment` o `merchant_order` solo si tu aplicación/producto efectivamente los emite. Sus estados no aprueban directamente esta compra. Un ID de payment o merchant_order no se envía como ID de Orders.

Este receptor espera **Webhooks firmados**, con `x-signature`, `x-request-id`, `data.id` en la query y el mismo ID en `body.data.id`. Admite IDs numéricos o cadenas en el cuerpo. No incorpora un receptor IPN antiguo sin firma (`topic`/`id`), ni desactiva la validación para aceptarlo. Si tu producto solo emite ese formato, requiere una adaptación específica, no desactivar la firma.

Los eventos que se puedan simular en el panel ayudan a comprobar transporte y firma. Un ID inventado no confirma un pedido: necesita existir y estar asociado a un intento local.

## 5. Arrancar y desplegar

Desarrollo, desde la raíz:

```bash
npm run dev
```

En despliegue, el frontend Astro permanece en Netlify y el backend NestJS debe ejecutarse en su alojamiento de backend con acceso a PostgreSQL. Subir únicamente los archivos del frontend a Netlify no publica NestJS ni su webhook.

**Actualiza backend y frontend de forma coordinada:** la firma GraphQL de `iniciarPago` cambia de `pedidoId` a `datos`, y `PagoAdmin.pedido` ahora puede ser `null`. Aplica la migración antes de iniciar el backend nuevo. Evita nuevas compras durante el cambio de versiones para no mezclar el checkout viejo con la API nueva. Usa tu comando de build existente de Netlify para el workspace front; el build local completo es `npm run build` desde la raíz.

No se ejecuta ni se publica automáticamente ningún despliegue con este paquete.

### Conciliación y reservas abandonadas

Un NestJS persistente ejecuta una revisión cada minuto, en lotes de hasta 20 intentos, ordenados por próxima revisión. El plazo local de reserva es 15 minutos y se envía `expiration_time: PT15M` a Orders. Las URLs y comportamiento de checkout siguen el contrato presente en el SDK instalado `mercadopago@3.6.1`; debes verificar que tu producto habilitado acepte este flujo online con `processing_mode: manual`, `checkout_url` y esa duración en la prueba real.

Al vencer o al pedir cancelar, se consulta la orden; si sigue abierta, se solicita `POST /v1/orders/{id}/cancel` y se vuelve a consultar. Solo un estado terminal verificado libera stock. No se libera simplemente porque hayan pasado 15 minutos. Si MP no permite cancelar todavía, la reserva continúa y queda una incidencia para reintentar. Los reintentos de pago dentro de una misma orden se solicitan deshabilitados (`config.online.retries.allowed=false`), de modo que un estado `failed` sea terminal para ese checkout.

Si el backend se suspende o se ejecuta como función, **no dependas de `setInterval`**. Programa un cron de backend cada minuto, con las mismas variables y acceso a la base:

```bash
node scripts/conciliar-pagos.cjs
```

Requiere backend compilado. En ese caso puedes poner `MP_RECONCILIATION_DISABLED=1` en el proceso web. El cron informa incidencias y sale con código 1 si quedan errores de verificación. Debe ejecutarse aunque nadie vuelva a la tienda. Ajusta capacidad/frecuencia si superas 20 intentos revisados por minuto; las consultas de retorno y los webhooks también concilian.

Si Mercado Pago no respondió después de crear la orden, se reutilizan el payload persistido y la misma clave de idempotencia. No borres esos intentos ni cambies la clave para forzar otro cobro. Si la creación fue rechazada por configuración, corrige esa configuración y revisa el intento; las reservas inciertas no se liberan manualmente sin verificar que no exista una orden cobrable.

## 6. Prueba funcional con tu cuenta de Mercado Pago

1. Inicia sesión en la tienda, agrega un producto con stock y abre checkout.
2. Completa los datos y pulsa pagar una sola vez. Se conserva el carrito; en el historial todavía no debe existir un pedido nuevo. El panel de pagos muestra el intento sin pedido confirmado.
3. Completa el checkout de Mercado Pago con el comprador y medio de prueba oficialmente indicados para México y tu producto.
4. Consulta el historial de entregas de Webhooks de Mercado Pago. Verifica la URL, código HTTP y cuerpo de respuesta. Revisa los logs del backend, no solo los del frontend Netlify.
5. Al acreditarse, debe aparecer exactamente un pedido `PAGADO` con pago `APROBADO`. El retorno muestra su número y descuenta del carrito las unidades compradas.
6. Repite con un resultado rechazado de prueba: no debe aparecer un pedido nuevo y el carrito debe seguir disponible.
7. Reenvía una notificación: no debe duplicar pedidos ni descontar stock otra vez.
8. Abre checkout y ciérralo sin pagar: revisa el intento desde la tienda, continúa el pago o solicita cancelar. Tras cancelación/vencimiento remoto confirmado, las unidades vuelven a estar disponibles.
9. Cierra el navegador después de pagar: el webhook/conciliador debe crear el pedido sin depender del retorno. Al volver a consultar el intento en ese navegador se ajusta el carrito.

No confirmes una compra por `status`, `collection_status` u otros parámetros manipulables de la URL del navegador. La página de retorno consulta al backend autenticado. Tampoco uses un endpoint propio para marcar pagos aprobados: las pruebas automatizadas simulan el proveedor fuera del servidor publicado.

## 7. Interpretar las respuestas y las incidencias

| Respuesta | Significado |
| --- | --- |
| `200 / CONFIRMADO` | Orden verificada y pedido creado. |
| `200 / YA_CONFIRMADO` | No se duplica el pedido; se registró el estado actual. |
| `200 / EN_PROCESO` | Notificación atendida; la orden aún no está acreditada. Se guardó el estado y se revisará otra vez. |
| `200 / RECHAZADO`, `CANCELADO`, `EXPIRADO` | Resultado terminal verificado; se liberó la reserva una sola vez. |
| `200 / IGNORADO_*` | Tipo o compra ajenos a esta integración; no se aprobó nada. |
| `200 / LEGACY_*` | Orden vinculada a un pedido del flujo anterior. |
| `401` | Faltan datos de firma o esta no coincide. |
| `400` | Cuerpo inválido o IDs diferentes entre query y cuerpo. |
| `503` | Resultado no verificable, fallo del proveedor o inconsistencia. Debe reintentarse y revisarse. |

El panel Administración → Pagos muestra `intentoId`, estado del intento, estado del proveedor y el último error de conciliación. Los logs identifican tipo, recurso, intento y resultado. No imprimen access tokens, firmas ni cuerpos completos con datos del comprador.

Una acreditación excepcional posterior a una liberación intenta readquirir stock antes de crear el pedido. Si no hay stock, se conserva la incidencia en proceso y se responde con error reintentable: requiere intervención para reposición o reembolso por el proveedor. No inventa un pedido imposible de entregar ni hace reembolsos automáticos.

Una orden ya confirmada que luego se consulta como `refunded` registra el pago como `REEMBOLSADO`. No cancela el pedido ni repone inventario automáticamente: una devolución física necesita su propio flujo. Contracargos y reembolsos parciales requieren tratamiento comercial específico; no forman parte de esta implementación.

## 8. Pruebas incluidas y verificaciones realizadas

Después de compilar el backend:

```bash
npm run build -w back
node --test scripts/test-pagos.cjs scripts/test-carrito.cjs
```

Estas pruebas usan PostgreSQL real y **simulan todas las llamadas a Mercado Pago**, sin enviar dinero ni requerir credenciales MP. Crean una base efímera `tl_test_mp_*`, aplican las cinco migraciones y eliminan únicamente esa base al terminar. `DATABASE_URL` debe apuntar a un servidor local/de pruebas cuyo usuario tenga permiso `CREATEDB`; no las ejecutes con un servidor de producción. Los valores ficticios de MP existen solo en el proceso de pruebas.

Se verificaron **18 pruebas**: reserva sin pedido; aprobación y duplicados concurrentes; rechazo y liberación; dispatch `order`/`payment`/`merchant_order`; firma inválida; IDs incompatibles; aislamiento entre usuarios; reintento tras timeout; vendedor/moneda/importes/referencia; expiración con red caída; carrera cancelación/aprobación; reservas concurrentes; pagos tardíos; reembolso; limpieza de carrito e integración HTTP GraphQL/webhook.

También se verificaron login BFF, retorno SSR autenticado y logout con eliminación de cookie mediante peticiones HTTP locales. Pasaron la compilación del backend, `astro check` y build del frontend, ESLint de los módulos nuevos/principales modificados, `git diff --check` y la suite existente `npm run test:api` contra el backend actualizado. La suite API anterior sigue comprobando las funciones históricas de pago al recibir; no es una prueba real contra Mercado Pago. Se mantiene un aviso informativo preexistente de variable no usada en la página de login.

**Pendiente en tu despliegue:** confirmar la habilitación del producto y el contrato de Orders con tu cuenta, realizar el checkout real de prueba y comprobar entrega/firma del webhook en tu URL pública. No se ejecutaron pagos contra Mercado Pago ni se desplegó en Netlify durante esta preparación.

## 9. Alcance del ZIP y reversión

`ARCHIVOS_SHA256.txt` lista los archivos incluidos y sus hashes. El ZIP incluye solo archivos actualizados/nuevos y esta guía; debes aplicarlo sobre el proyecto existente. No contiene `node_modules`, `dist`, `.git`, bases de datos o archivos `.env` privados.

La migración es aditiva, pero cambia la nulabilidad de `pagos.pedido_id`: una versión antigua del panel puede fallar al leer pagos sin pedido. Si necesitas volver atrás, conserva el respaldo y coordina versiones; no borres intentos o pagos ni restaures la obligatoriedad de `pedido_id` mientras existan pagos sin pedido. Las compras nuevas se habilitan de nuevo después de verificar backend y frontend compatibles.
