# Corrección del botón Mercado Pago bloqueado

Preparada sobre `main` commit `6e87c11b930174b661123e8e25837a57178eccb7`.

## Qué copiar

Este ZIP es una actualización pequeña del repositorio que ya actualizaste. No es el paquete completo anterior.

1. Reemplaza `front/src/screens/Checkout.tsx`.
2. Añade `front/src/lib/verificar-checkout.ts`.
3. Opcionalmente añade `scripts/test-checkout-recuperacion.cjs` para ejecutar las regresiones.
4. Conserva los demás archivos y tus variables privadas.

El backend de ese commit ya incluye las consultas `intentoActivo` y `estadoIntento` utilizadas por esta corrección. No se modifica el backend ni se añade una migración o variable de entorno.

## Comportamiento corregido

- Una consulta fallida siempre termina el estado visual de comprobación, muestra el error y permite reintentar. No habilita otro cobro mientras el resultado sea incierto.
- El identificador guardado en el navegador se consulta con `estadoIntento`; no se considera pendiente solo porque esté en localStorage.
- Si el backend confirma `NOT_FOUND`, se elimina esa referencia local y se comprueba si existe otro intento activo.
- Intentos rechazados, cancelados o expirados ya no bloquean una compra nueva.
- Si el intento estaba confirmado, se ajusta el carrito con la lógica existente antes de quitar la referencia.
- Un intento verdaderamente en proceso conserva la protección y el enlace para revisar, continuar o cancelar el pago desde la página de retorno.
- Si `iniciarPago` falla antes de crear el intento, la recuperación verifica y elimina el ID inexistente. Se mantiene visible el error original: por ejemplo, una variable de Mercado Pago faltante.
- Si hubo un timeout después de crear el intento, se recupera el intento existente. No se borra su referencia ni se genera automáticamente otro cobro.
- El formulario permite escribir mientras se comprueba el backend. Solo se deshabilita mientras se envía la solicitud.

No borres manualmente `tl-checkout-*` ni quites todas las condiciones del botón como solución: podrías perder la referencia de un pago cuyo resultado aún no conoces.

## Aplicar y desplegar

Desde la raíz del proyecto:

```bash
npm run build -w front
node --test scripts/test-checkout-recuperacion.cjs
```

Cuando ambos pasos terminen bien, incluye los dos archivos de frontend en tu repositorio de despliegue y vuelve a desplegar Netlify. Publicar este ZIP en una rama de entrega no cambia por sí mismo el código que Netlify está ejecutando ni modifica main.

Mantén en Netlify `BACKEND_GRAPHQL_URL` apuntando a `https://TU-BACKEND/graphql`. Render debe estar ejecutando el backend actualizado. Si la comprobación sigue fallando, ahora se mostrará el mensaje real y un botón para reintentar. Un error de conexión o una migración pendiente no se arreglan eliminando la protección del cobro.

## Verificación manual

1. Abre el checkout con un usuario autenticado.
2. Si el ID local era inexistente o terminado, debe poder habilitarse Pagar con Mercado Pago tras comprobarlo.
3. Si hay un intento real abierto, sigue su enlace, continúa o cancela el pago. Después regresa al checkout o usa Actualizar estado del pago.
4. Si aparece un error de consulta, utiliza Reintentar comprobación después de corregir la conexión o configuración.
5. Completa la dirección (mínimo 10 caracteres) y los campos requeridos. Si el backend devuelve checkoutUrl, el navegador abre Mercado Pago.
6. Si Mercado Pago o el backend rechazan iniciar la operación, revisa el error original mostrado. Corregir este bloqueo del frontend no sustituye la configuración de credenciales y URLs del proveedor.

## Pruebas realizadas

13 regresiones pasaron ejecutando el componente y el helper reales con React/API simulados: estados iniciales, fallo y reintento, ID inexistente, estados terminales, compra confirmada, intento activo real, fallo de red, intento de otro dispositivo, rechazo antes de crear, timeout después de crear y redirección al checkout con una única solicitud.

También pasaron `astro check`, build del frontend, ESLint de los dos módulos modificados/nuevos y `git diff --check`. Se mantiene una sugerencia informativa preexistente sobre una variable no usada en la página de login.

No se realizó un pago contra Mercado Pago ni se desplegó en tu cuenta de Netlify. El ZIP no contiene secretos ni archivos .env. Incluye `ARCHIVOS_SHA256.txt` para verificar sus archivos.
